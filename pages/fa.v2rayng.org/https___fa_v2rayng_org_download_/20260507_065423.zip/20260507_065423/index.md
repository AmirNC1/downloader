# Visited: https://fa.v2rayng.org/download/
**Time:** Thu May  7 06:54:27 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (5 files)
## Downloaded Media Files

![cropped-favicon-180x180.png](./media/cropped-favicon-180x180.png)
![cropped-favicon-192x192.png](./media/cropped-favicon-192x192.png)
![cropped-favicon-32x32.png](./media/cropped-favicon-32x32.png)
![favicon-55x55.png](./media/favicon-55x55.png)
![hqdefault.jpg](./media/hqdefault.jpg)

## Other Links
- [#content](#content)
- [data:text/javascript;base64,](data:text/javascript;base64,)
- [https://fa.v2rayng.org/](https://fa.v2rayng.org/)
- [https://fa.v2rayng.org/comments/feed/](https://fa.v2rayng.org/comments/feed/)
- [https://fa.v2rayng.org/download/](https://fa.v2rayng.org/download/)
- [https://fa.v2rayng.org/feed/](https://fa.v2rayng.org/feed/)
- [https://fa.v2rayng.org/wp-content/cache/min/1/wp-content/plugins/ninja-tables-pro/assets/js/ninja-tables-pro.js?ver=1760930214](https://fa.v2rayng.org/wp-content/cache/min/1/wp-content/plugins/ninja-tables-pro/assets/js/ninja-tables-pro.js?ver=1760930214)
- [https://fa.v2rayng.org/wp-content/cache/min/1/wp-content/plugins/ninja-tables/assets/js/ninja-tables-footable.js?ver=1760930214](https://fa.v2rayng.org/wp-content/cache/min/1/wp-content/plugins/ninja-tables/assets/js/ninja-tables-footable.js?ver=1760930214)
- [https://fa.v2rayng.org/wp-content/cache/min/1/wp-content/uploads/astra-addon/astra-addon-69e3a2a8b1d773-11558203.js?ver=1776525995](https://fa.v2rayng.org/wp-content/cache/min/1/wp-content/uploads/astra-addon/astra-addon-69e3a2a8b1d773-11558203.js?ver=1776525995)
- [https://fa.v2rayng.org/wp-content/plugins/astra-addon/assets/js/minified/purify.min.js?ver=4.13.1](https://fa.v2rayng.org/wp-content/plugins/astra-addon/assets/js/minified/purify.min.js?ver=4.13.1)
- [https://fa.v2rayng.org/wp-content/plugins/ninja-tables/assets/libs/footable/js/footable.min.js?ver=3.1.5](https://fa.v2rayng.org/wp-content/plugins/ninja-tables/assets/libs/footable/js/footable.min.js?ver=3.1.5)
- [https://fa.v2rayng.org/wp-content/plugins/wp-rocket/assets/js/lazyload/17.8.3/lazyload.min.js](https://fa.v2rayng.org/wp-content/plugins/wp-rocket/assets/js/lazyload/17.8.3/lazyload.min.js)
- [https://fa.v2rayng.org/wp-content/themes/astra/assets/js/minified/frontend.min.js?ver=4.13.1](https://fa.v2rayng.org/wp-content/themes/astra/assets/js/minified/frontend.min.js?ver=4.13.1)
- [https://fa.v2rayng.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1](https://fa.v2rayng.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1)
- [https://fa.v2rayng.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1](https://fa.v2rayng.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1)
- [https://fa.v2rayng.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ffa.v2rayng.org%2Fdownload%2F](https://fa.v2rayng.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ffa.v2rayng.org%2Fdownload%2F)
- [https://fa.v2rayng.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ffa.v2rayng.org%2Fdownload%2F&#038;format=xml](https://fa.v2rayng.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ffa.v2rayng.org%2Fdownload%2F&#038;format=xml)
- [https://gmpg.org/xfn/11](https://gmpg.org/xfn/11)
- [https://www.googletagmanager.com](https://www.googletagmanager.com)
- [https://www.googletagmanager.com/ns.html?id=GTM-NBR775W4](https://www.googletagmanager.com/ns.html?id=GTM-NBR775W4)

## Stats
- Links: 25
- Media: 5
